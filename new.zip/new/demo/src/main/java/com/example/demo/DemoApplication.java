package com.example.demo;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.demo.entity.User;

@SpringBootApplication
public class DemoApplication {

	public void initUsers() {
		List<User> users =Stream.of(
				new User(id:101, userName:"gkm", email:"hkm@gmail.com")
				new User(id:101, userName:"gkm", email:"hkm@gmail.com")
				.collect.(Collectors.toList());
	}
	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}

}
