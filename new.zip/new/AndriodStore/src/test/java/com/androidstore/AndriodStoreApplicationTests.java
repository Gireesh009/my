package com.androidstore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AndriodStoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
